"""Render the Hand Grip Strength nudge PNG (1024 x 1536).

    python render.py --out out.png \
        --test-date "Sep 18, 2026" --name "Dr Pavan" \
        --right 48.1 --left 42.7 \
        --right-label Average --left-label Average

Requires: jinja2, playwright  (pip install jinja2 playwright && playwright install chromium)
"""
import argparse, pathlib, tempfile
from jinja2 import Template
from playwright.sync_api import sync_playwright

HERE = pathlib.Path(__file__).parent
WIDTH, HEIGHT = 1024, 1536


def build_html(ctx: dict) -> str:
    tpl = Template((HERE / "template.html").read_text(encoding="utf-8"))
    return tpl.render(**ctx)


def render(ctx: dict, out: pathlib.Path) -> pathlib.Path:
    html = build_html(ctx)
    # write beside the template so relative assets/ paths resolve
    with tempfile.NamedTemporaryFile("w", suffix=".html", dir=HERE,
                                     encoding="utf-8", delete=False) as fh:
        fh.write(html)
        tmp = pathlib.Path(fh.name)
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch()
            page = browser.new_page(viewport={"width": WIDTH, "height": HEIGHT},
                                    device_scale_factor=1)
            page.goto(tmp.as_uri())
            page.wait_for_load_state("networkidle")
            page.wait_for_timeout(400)          # let webfonts settle
            page.screenshot(path=str(out),
                            clip={"x": 0, "y": 0, "width": WIDTH, "height": HEIGHT})
            browser.close()
    finally:
        tmp.unlink(missing_ok=True)
    return out


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="grip_report.png")
    p.add_argument("--test-date", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--right", type=float, required=True)
    p.add_argument("--left", type=float, required=True)
    p.add_argument("--right-label", required=True)
    p.add_argument("--left-label", required=True)
    p.add_argument("--test-name", default="Hand Grip Strength")
    a = p.parse_args()

    ctx = {
        "test_date":    a.test_date,
        "name":         a.name,
        "test_name":    a.test_name,
        "right":        f"{a.right:.1f}",
        "left":         f"{a.left:.1f}",
        "right_label":  a.right_label,
        "left_label":   a.left_label,
    }
    out = render(ctx, pathlib.Path(a.out))
    print(f"wrote {out} ({WIDTH}x{HEIGHT})")


if __name__ == "__main__":
    main()
