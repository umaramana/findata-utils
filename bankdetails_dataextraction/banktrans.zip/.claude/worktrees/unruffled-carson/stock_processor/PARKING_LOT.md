# Parking Lot - Future Features

---

## Bank Transaction Processor — Bug Triage (Pending Approval)

**File:** `extract_bank_txns.py` (repo root)
**Engine:** Tesseract OCR on scanned Citibank statement images (JPG/PNG)
**Output columns:** `statement_period | date | description | subtracted | added | balance | flag | source_page`

Issues found during manual editing of processor output. Categorized below with root cause analysis and fix options. **Awaiting approval before implementation.**

---

### Category A: Row Classification

#### [BTP-1] Page Total Row Misidentified as Transaction Row
**Observed:** The "Total Subtracted/Added" page-summary row is being included as a real transaction, inflating column sums and triggering a spurious mismatch.

**Root Cause in code:** `parse_transactions()` first checks `is_boilerplate(line)` which does a substring match against `BOILERPLATE_MARKERS` (includes `'Total Subtracted'`). If Tesseract OCR garbles the text — e.g., `"Totai Subtracted"` or `"Total 5ubtracted"` — the exact-string check fails. If that garbled line also happens to start with something matching `txn_pattern` (`^\d{2}/\d{2}`) it is parsed as a transaction. Even without a date prefix, the amounts from that line can bleed into the previous transaction as a continuation.

**Fix Options:**

| Option | Approach | Notes |
|--------|----------|-------|
| A | **Math check**: after `parse_transactions()`, sum all `subtracted` and `added` values for the page. If any single transaction's value equals or closely matches that page-level sum, flag and exclude it as a total row. | Works regardless of OCR quality. False-positive risk if a coincidental transaction equals the sum of others. |
| B | **Fuzzy regex boilerplate** *(replaces bold-font idea — N/A here since input is scanned images, not Excel)*: replace exact-string check in `is_boilerplate()` with regex patterns that tolerate OCR noise, e.g. `re.search(r'tot[a4]l\s+sub', line, re.IGNORECASE)`. | Low false-positive risk. Handles common OCR substitutions (`a→4`, `l→1`, `a→o`). Requires maintaining a regex list. |
| C | **Combined (Recommended)**: Option B first (fuzzy boilerplate — fast, catches OCR variants), then Option A as fallback math check after all rows are parsed. | Most robust for this OCR context. B catches garbled labels; A catches any that slip through. Bold-font detection is **not applicable** here (Tesseract on images). |

**Recommendation:** Option C. Fuzzy regex fixes the root cause; math check is the safety net.

---

#### [BTP-2] All Transactions on Page Flagged When a Page Has Missing Rows
**Observed:** When a page total mismatch fires, **every valid transaction** on that page gets `flag = 'VERIFY - page total mismatch'`, making it impossible to tell which rows are OK and which need review.

**Root Cause in code:** In `main()`, after the mismatch check:
```python
page_flag = 'VERIFY - page total mismatch'
...
for t in txns:
    t['flag'] = page_flag   # blindly stamps ALL rows on the page
```
The sentinel placeholder row (description: `'*** MISSING ROWS - check page manually ***'`) is the right idea — but individual valid rows should not get the same flag.

**Fix:**
- Keep `page_flag = ''` for valid transactions.
- Only the sentinel row gets `flag = 'VERIFY - missing rows (sub gap: X, add gap: Y)'`.
- Optionally add a `source_note` field on valid rows: `'Page has missing rows — these values may be correct'` to preserve traceability without treating them as errors.

---

### Category B: OCR / Number Parsing

#### [BTP-3] Digit Misreading — 1 Misread as 4 or 7 (Not Caught as Error)
**Observed:** A numeric value in the output is wrong (`1` OCR'd as `4` or `7`). Seen in both amounts and dates (e.g., `44/19` in CSV instead of `11/19`). No error is raised because the misread value is syntactically valid.

**Root Cause in code:** Tesseract confuses `1` with `4` or `7` in some handwritten/printed fonts. The `amount_pattern` and `txn_pattern` in `parse_transactions()` accept any digit sequence — no cross-validation against neighboring rows.
The `balance` column IS already parsed and written to CSV, making per-row reconciliation feasible without any new parsing.

**Fix Options:**

| Option | Approach | Notes |
|--------|----------|-------|
| A | **Balance reconciliation**: after all pages are parsed, walk rows in order. For consecutive rows with non-empty balance, check `prev_balance + added − subtracted ≈ current_balance`. If gap exceeds tolerance, flag the row: `'VERIFY - balance does not reconcile'`. | Strong signal. Catches misreads in amounts AND in balance itself. No auto-correct — surfaces for manual review. |
| B | **Outlier ratio detection**: flag rows where `subtracted` or `added` differs from nearby-row median by ~4× or ~7×. | Too noisy — legitimate large transactions (wire transfers, checks) would fire constantly. |
| C | **Flag on residual mismatch only** (no extra code): when a page total mismatch exists and BTP-1 has already been ruled out (no total row), note in the sentinel: `'Possible misread — balance does not reconcile, verify original image'`. | Minimal code. Less precise — only fires at page level, not row level. |

**Recommendation:** Option A. The `balance` column is already available in the output; reconciliation walk is straightforward and row-level precision is needed to be useful.

---

### Category C: Column Value Placement — `_build_txn()` Routing Errors

All four issues below trace to `_build_txn()` in `extract_bank_txns.py`. The function routes amounts into `subtracted`/`added`/`balance` based on:
1. `len(amounts)` — 1, 2, or 3 amounts found on the OCR line
2. `txn_type` — `'debit'` / `'credit'` / `'unknown'` from keyword match on description

**Shared fix for BTP-4 through BTP-7:** After `_build_txn()` returns a row, run balance reconciliation (`prev_balance + added − subtracted ≈ current_balance`). If it fails, apply targeted re-routing per the patterns below. Balance column is already parsed, so this requires no new OCR work.

---

#### [BTP-4] Balance Value Placed in `subtracted` (Sub Not Read)
**Observed:** The `subtracted` column contains what is actually the new account balance; the real debit amount was missed entirely.

**Code path:** `len(amounts) == 1`, `txn_type == 'debit'` → `amt_subtracted = amounts[0]`. When OCR only picks up the balance figure (sub amount missed or merged into description), the balance goes into `subtracted`.

**Detection via reconciliation:** `subtracted` is set but `prev_balance − subtracted ≠ current_balance`; instead `amounts[0] == next_row_balance` (it's the new balance, not a debit).

---

#### [BTP-5] Add Value Placed in `subtracted`
**Observed:** A credit (deposit/incoming wire) amount appears in `subtracted`. Seen in CSV: `"Incoming Wire Transfer WIRE FROM TEACHERS FEDERAL CREDIT UNION", subtracted=21512.83, added=''`.

**Code path — two possible triggers:**
1. `len(amounts) == 3`: code always routes `amounts[0]→subtracted`, `amounts[1]→added` ignoring `txn_type`. If OCR picks up a stray number making it 3 amounts, a credit's amount lands in `subtracted`.
2. `len(amounts) == 2`, `txn_type == 'unknown'`: description OCR'd poorly, no keyword matches → defaults to `subtracted` (`else: amt_subtracted = pre_balance_amt` + `[CHECK TYPE]` prefix).

**Detection via reconciliation:** `subtracted` is set, `added` is empty, but `prev_balance + subtracted_val ≈ current_balance` (balance went UP, consistent with a credit not a debit).

---

#### [BTP-6] Sub Value Concatenated into Description; Balance Placed in `subtracted`
**Observed:** Description field contains a trailing number (e.g., `"ACH PAYMENT 04/05. ...Transfer to Bankcard 09:50a #4316 298.35, ONLINE Reference # 006751"`). The balance shifted into `subtracted`.

**Code path:** `amount_pattern` requires whitespace before digits (`(?:^|(?<=\s))`). When OCR fuses the debit amount to surrounding text without a space, the amount is invisible to `amount_pattern`. The code then only finds the balance on the line, and with `txn_type == 'debit'`, routes balance → `subtracted`.

**Detection:** regex check on description after `_build_txn()`: `re.search(r'\b\d{1,3}(?:,\d{3})*\.\d{2}[,\s]*$', description)`. If found, extract that trailing amount as the real debit, treat the balance-in-`subtracted` as the true balance.

---

#### [BTP-7] Sub Not Read; Balance Placed in `subtracted`
**Observed:** `subtracted` is empty (sub value lost entirely) and a wrong large value appears in `subtracted` that matches the account balance.

**Code path:** Same as BTP-4 — `len(amounts) == 1`, `txn_type == 'debit'`. OCR sees only 1 number on the line (the balance); sub was on a different part of the page that OCR missed.

**Distinction from BTP-4:** BTP-4 is where the balance is the only amount and the sub amount was simply not on this line's OCR output; BTP-7 is where the sub was on the page but OCR lost it (garbled or merged into boilerplate). Detection is the same.

**Note:** BTP-4 and BTP-7 resolve to identical detection code. The difference is forensic (what OCR did), not programmatic.

---

### Category D: Error Reporting

#### [BTP-8] All Mismatches Labeled "Missing Rows" Regardless of Actual Cause
**Observed:** Whether the real problem is a garbled total row (BTP-1), a column routing error (BTP-4–7), or a digit misread (BTP-3), the output always shows `'*** MISSING ROWS - check page manually ***'` in the sentinel row and `'VERIFY - page total mismatch'` on all other rows of that page.

**Root Cause in code:** The only diagnostic branch in `main()` is:
```python
if abs(sub_gap) > 0.02 or abs(add_gap) > 0.02:
    page_flag = 'VERIFY - page total mismatch'
    sentinel_rows.append({'description': '*** MISSING ROWS - check page manually ***', ...})
```
There is no attempt to distinguish *why* totals don't match. A column shift (BTP-5) produces the same error output as a genuinely missing row.

**Fix — Tiered diagnostic in the mismatch block:**

| Check order | Condition | Output |
|-------------|-----------|--------|
| 1 | Total mismatch AND a row has reconciliation failure (BTP-3/4/5/6/7) | `'VERIFY - column placement or misread at row R — balance does not reconcile'` |
| 2 | Total mismatch AND all rows reconcile individually but sums are off | `'VERIFY - missing rows (sub gap: X, add gap: Y)'` |
| 3 | Total mismatch AND no page total line found in OCR (can't compare) | `'VERIFY - no page total detected, manual check required'` |

Each sentinel row gets only the flag appropriate to the detected cause. Valid transaction rows (BTP-2) get no flag.

---

## Subtotal Aggregation per Stock
- Instead of processing all individual transactions for a stock, use the broker's subtotal row for that stock
- Could reduce processing errors and simplify output (e.g., 10 transactions → 1 subtotal row)
- Challenge: each broker has a different format for subtotal rows
- Needs broker-specific detection logic (Schwab, Fidelity, Robinhood)

## PDF vs Excel QC (Quality Check & Auto-Correct) — IMPLEMENTED (Step 2B)
Implemented in `pdf_qc.py` and `app.py`. PDF page 1 is a summary, page 2+ are data pages.
PDF page N maps to Excel sheet N-2 (page 2 → sheet 0).

## PDF Summary Page QC (Page 1)
- PDF page 1 contains a summary/totals page
- Future feature: compare summary totals against the sum of all processed transactions
- Could catch errors that per-page QC misses (e.g., missing pages, double-counted rows)
